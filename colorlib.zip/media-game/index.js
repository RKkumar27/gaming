function triger(checking){
    console.log(checking);
}